package com.jameseng.javarestspringboot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JavaRestSpringBootApplication {

	public static void main(String[] args) {
		SpringApplication.run(JavaRestSpringBootApplication.class, args);
	}

}
